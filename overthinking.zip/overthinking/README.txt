The Art of Overthinking
Open index.html in a browser. No build step.
Live URL: (not published)
GitHub: (not published)

Design notes: each click mutates the thought (string transforms), nudges it, and spawns 2-3 copies at random positions (capped at 150).
Accessibility: thoughts are real <button>s (keyboard + visible red focus ring), live-region counter, semantic header/main/section, poem is static text outside the chaos, prefers-reduced-motion disables animation, dark ink on cream contrast.
Ethics: "Calm down" toggle stops motion; cap prevents browser overload.
